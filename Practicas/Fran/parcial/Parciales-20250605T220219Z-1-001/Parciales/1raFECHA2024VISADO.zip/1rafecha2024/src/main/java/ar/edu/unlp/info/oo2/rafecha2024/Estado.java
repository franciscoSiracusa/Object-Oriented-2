package ar.edu.unlp.info.oo2.rafecha2024;

public interface Estado {
	
	public void pagarCuota(Prestamo prestamo);
	
	public double cancelarPrestamo(Prestamo prestamo);

}
