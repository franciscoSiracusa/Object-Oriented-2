package parcialPiezas;

public class PiezaSimple extends Pieza {
	private int bateria, potencia;

	public PiezaSimple(String n, int bateria, int potencia) {
		super(n);
		this.bateria = bateria;
		this.potencia = potencia;
	}

	public double getBateria() {
		return this.bateria;
	}

	public double getPotencia() {
		return this.potencia;
	}

	public String toString() {
		return this.nombre + ", batería al " + this.bateria + "%, potencia de " + this.potencia + "w.";
	}

}
