package testParcialJuan;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import parcialPiezas.*;

public class PiezaTest {
	private PiezaSimple s1, s2, s3, s4;
	private PiezaCompuesta co1, co2, co3;

	@BeforeEach
	public void setUp() {
		this.s1 = new PiezaSimple("Simple 1", 40, 50);
		this.s2 = new PiezaSimple("Simple 2", 16, 18);
		this.s3 = new PiezaSimple("Simple 3", 20, 45);
		this.s4 = new PiezaSimple("Simple 4", 80, 359);
		this.co1 = new PiezaCompuesta("Compuesta 1");
		this.co2 = new PiezaCompuesta("Compuesta 2");
		this.co3 = new PiezaCompuesta("Compuesta 3");

		this.co3.agregarPieza(s3);
		this.co3.agregarPieza(s3);
		this.co3.setEstrategia(new AhorroDeEnergia());

		this.co2.agregarPieza(co3);
		this.co2.agregarPieza(s2);
		this.co2.agregarPieza(s4);

		this.co1.agregarPieza(s1);
		this.co1.agregarPieza(s2);
		this.co1.agregarPieza(co2);
		this.co1.setEstrategia(new PotenciaMaxima());
	}

	@Test
	public void testPiezas() {
		assertEquals(16, this.co3.getBateria());
		assertEquals(31.5, this.co3.getPotencia());
		assertEquals(37.33, this.co2.getBateria());
		assertEquals(136.17, this.co2.getPotencia());
		assertEquals(46.67, this.co1.getBateria());
		assertEquals(81.67, this.co1.getPotencia());
	}
	
	@Test
	public void testImpresion() {
		//assertEquals("",this.s1.toString());
		assertEquals("",this.co1.toString());
		
	}
}
