package parcialPiezas;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class PiezaCompuesta extends Pieza {
	private List<Pieza> piezas;
	private Strategy estrategia;

	public PiezaCompuesta(String n) {
		super(n);
		this.piezas = new ArrayList<Pieza>();
		this.estrategia = new PotenciaMedia();
	}

	public void setEstrategia(Strategy s) {
		this.estrategia = s;
	}

	public void agregarPieza(Pieza p) {
		this.piezas.add(p);
	}

	public double promedioBateria() {
		return this.piezas.stream().mapToDouble(pieza -> pieza.getBateria()).average().orElse(0);
	}

	public double promedioPotencia() {
		return this.piezas.stream().mapToDouble(pieza -> pieza.getPotencia()).average().orElse(0);
	}

	public double getBateria() {
		return this.estrategia.calcularBateria(this);
	}

	public double getPotencia() {
		return this.estrategia.calcularPotencia(this);
	}

	public String toString() {
		return this.nombre + "-" + this.estrategia.getNombreEstrategia() + "\n"
				+ this.piezas.stream().map(pieza -> pieza.toString()).collect(Collectors.joining("\n"));
	}

}
