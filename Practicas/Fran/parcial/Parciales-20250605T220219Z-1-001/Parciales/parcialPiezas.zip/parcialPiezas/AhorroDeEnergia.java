package parcialPiezas;

public class AhorroDeEnergia extends Strategy {
	private final double CONFIGURACION_BATERIA = 0.8;
	private final double CONFIGURACION_POTENCIA = 0.7;

	public double configuracionBateria() {
		return this.CONFIGURACION_BATERIA;
	}

	public double configuracionPotencia() {
		return this.CONFIGURACION_POTENCIA;
	}

	public String getNombreEstrategia() {
		return "Ahorro de energía";
	}

}
