package parcialPiezas;

public class PotenciaMaxima extends Strategy {
	private final double CONFIGURACION_BATERIA = 1.5;
	private final double CONFIGURACION_POTENCIA = 1.2;

	public double configuracionBateria() {
		return this.CONFIGURACION_BATERIA;
	}

	public double configuracionPotencia() {
		return this.CONFIGURACION_POTENCIA;
	}

	public String getNombreEstrategia() {
		return "Potencia Máxima";
	}

}
