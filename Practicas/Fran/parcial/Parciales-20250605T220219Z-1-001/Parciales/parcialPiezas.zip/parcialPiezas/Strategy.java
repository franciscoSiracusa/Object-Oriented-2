package parcialPiezas;

public abstract class Strategy {

	public double calcularBateria(PiezaCompuesta p) {
		return Math.round(p.promedioBateria() * this.configuracionBateria() * 100.00) / 100.00;
	}

	public double calcularPotencia(PiezaCompuesta p) {
		return Math.round(p.promedioPotencia() * this.configuracionPotencia() * 100.00) / 100.00;
	}

	public abstract double configuracionBateria();

	public abstract double configuracionPotencia();

	public abstract String getNombreEstrategia();
}
