package parcialPiezas;

public class PotenciaMedia extends Strategy {
	private final int CONFIGURACION = 1;

	public double configuracionBateria() {
		return this.CONFIGURACION;
	}

	public double configuracionPotencia() {
		return this.CONFIGURACION;
	}

	public String getNombreEstrategia() {
		return "Potencia Media";
	}

}
