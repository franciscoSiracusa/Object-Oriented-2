package parcialPiezas;

public abstract class Pieza {
	protected String nombre;
	
	public Pieza(String n) {
		this.nombre = n;
	}
	
	public abstract double getBateria();
	
	public abstract double getPotencia();
	
	public abstract String toString();
}
